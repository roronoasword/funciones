from funciones import agregar_producto
from funciones import aplicar_descuento
from funciones import generar_total
from funciones import carrito

print("--- 🛒 BIENVENIDO A LA TIENDA PYTHON ---")
    
while True:
    print("\nOpciones: [1] Agregar Producto | [2] Finalizar y Pagar | [3] Salir")
    opcion = input("Selecciona una opción: ")

    if opcion == "1":
        nombre = input("Nombre del producto: ")
        try:
            precio = float(input(f"Precio de {nombre}: "))
            cantidad = input(f"Cantidad (Presiona Enter para 1): ")
            cantidad = int(cantidad) if cantidad else 1
            
            agregar_producto(nombre, precio, cantidad)
        except ValueError:
            print("❌ Error: Ingresa valores numéricos válidos.")

    elif opcion == "2":
        if not carrito:
            print("⚠ Agrega al menos un producto primero.")
            continue
        
        # Preguntar por cupón
        tiene_cupon = input("\n¿Tienes un cupón de descuento? (s/n): ").lower()
        desc_valor = 0.0
        if tiene_cupon == "s":
            codigo = input("Ingresa el código: ").upper()
            desc_valor = aplicar_descuento(codigo)
        
        generar_total(desc_valor)
        break # Terminamos la compra

    elif opcion == "3":
        print("¡Gracias por visitarnos!")
        break
    else:
        print("Opción no válida.")