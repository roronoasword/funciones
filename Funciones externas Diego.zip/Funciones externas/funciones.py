carrito = []

# --- Tus funciones base ---

def agregar_producto(nombre, precio, cantidad=1):
    for item in carrito:
        if item["nombre"].lower() == nombre.lower(): # .lower() para evitar duplicados por mayúsculas
            item["cantidad"] += cantidad
            print(f"  ✔ '{nombre}' actualizado (nueva cantidad: {item['cantidad']})")
            return
    
    carrito.append({"nombre": nombre, "precio": precio, "cantidad": cantidad})
    print(f"  ✔ '{nombre}' agregado al carrito (x{cantidad})")

def aplicar_descuento(codigo):
    descuentos = {
        "PROMO10": 0.10,
        "DESCUENTO20": 0.20,
        "MITAD50": 0.50,
    }
    if codigo in descuentos:
        porcentaje = descuentos[codigo]
        print(f"  ✔ Cupón '{codigo}' aplicado: {int(porcentaje*100)}% de descuento")
        return porcentaje
    else:
        print(f"  ✘ Cupón '{codigo}' no válido")
        return 0.0

def generar_total(descuento=0.0):
    if not carrito:
        print("\n  ⚠ El carrito está vacío. No hay nada que cobrar.")
        return

    subtotal = sum(p["precio"] * p["cantidad"] for p in carrito)
    ahorro = subtotal * descuento
    total = subtotal - ahorro

    print("\n" + "=" * 48)
    print(f"{'🛒  RESUMEN DE COMPRA':^48}")
    print("=" * 48)
    print(f"  {'Producto':<20} {'P.Unit':>7} {'Cant':>5} {'Subtotal':>9}")
    print(f"  {'-'*44}")

    for item in carrito:
        sub = item["precio"] * item["cantidad"]
        print(f"  {item['nombre']:<20} ${item['precio']:>6.2f} {item['cantidad']:>5}  ${sub:>8.2f}")

    print(f"  {'-'*44}")
    print(f"  {'Subtotal':<35} ${subtotal:>8.2f}")

    if descuento > 0:
        print(f"  {'Descuento aplicado':<35}-${ahorro:>8.2f}")

    print(f"  {'TOTAL A PAGAR':<35} ${total:>8.2f}")
    print("=" * 48)

